# SneakerVibe – Vercel Deployment

## Schritte zur Live-Demo

1. Repo auf GitHub hochladen
2. Gehe auf https://vercel.com
3. Klicke auf "New Project" > Wähle dieses Repo aus
4. Setze die Einstellungen:

- **Framework Preset**: Andere
- **Build Command**: `npx expo export --platform web`
- **Output Directory**: `dist`

5. Starte den Build – fertig! Deine App ist live!

👉 Optional: Expo vorher mit `npm install -g expo-cli` installieren
